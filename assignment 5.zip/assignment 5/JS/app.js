
/*  question One*/

let max=(a, b)=> {
    if (a > b)
        return "the maximum number is: " + a;
    else if (a < b)
        return "the maximum number is: " + b;
    else
        return "there is no maxum number. all numbers are equal";

}
/*
console.log(max(6, 4));

// output will be:
//the maximum number is: 6

console.log(max(3, 4));

// output will be:
//the maximum number is: 4

console.log(max(4, 4));

// output will be:
//there is no maxum number. all numbers are equal

*/


/*Question 2 */
/*
let maxOfThree=(a, b, c) =>{
    if (a === b && a === c)
        return "numbers are equal. there is no maximum"
    if (a > b && a > c)
        return "the maximum number is: " + a;
    else if (b > c)
        return "the maximum number is: " + b;
    else
        return "the maximum number is: " + c;


}

console.log(maxOfThree(4, 5, 4));
// output will be:
//the maximum number is: 5

console.log(maxOfThree(6, 5, 4));
// output will be:
//the maximum number is: 6

console.log(maxOfThree(4, 4, 4));
// output will be:
//numbers are equal. there is no maximum

*/



/*Question 3 */

let isVowel=(x)=> {
    let vowels = new Array('a', 'A', 'e', "E", 'i', 'I', 'o', 'O', 'u', 'U');
    for (let i = 0; i < vowels.length; i++) {
        if (vowels[i] === x)
            return true;
    }
    return false;
}


console.log(isVowel("A"));
//output: True

console.log(isVowel("a"));
//output: True

console.log(isVowel("d"));
//output: false


/*Question 4 */


function multiply(arrayNum) {
    if (!(arrayNum instanceof Array)) {
        return "invalid input of array";
    }
    else{
    let product = 1;
    for (let i = 0; i < arrayNum.length; i++) {
        product *= arrayNum[i];
    }
    return "The product of array elements is:" + product;
    }
}

function sum(arrayNum, callback) {
        let sum;
    if (!(arrayNum instanceof Array)) {
        console.log("invalid input of array");
        return;
    }
    else{
         sum = 0;
    for (let i = 0; i < arrayNum.length; i++) {
        sum += arrayNum[i];
    }
    
    }


    console.log("The sum of the array elements is: " + sum);

    console.log(callback(arrayNum))

}

/*
 var arr = [5, 4, 3, 2]
 sum(arr, multiply);
 //the output will be:
 //The sum of the array elements is: 14
 //The product of array elements is:120

 
sum(1, multiply);
//the output will be:
 //invalid input of array
*/

//another way of Question 4

function multiply(arrayNum) {
    if (!(arrayNum instanceof Array)) {
        return "invalid input of array";
    }
    else {

        let product = 1;
        for (let i = 0; i < arrayNum.length; i++) {
            product *= arrayNum[i];
        }
        return "The product of array elements is:" + product;
    }
}

function sum(arrayNum) {
    if (!(arrayNum instanceof Array)) {
        return "invalid input of array";
    }
    else {
        let sum = 0;
        for (let i = 0; i < arrayNum.length; i++) {
            sum += arrayNum[i];
        }
        return "the sum of array elements is: " + sum;
    }
}


/*
console.log(sum(1));
console.log(multiply(1));

//output will be:
//invalid input of array
//invalid input of array0

var arr = [5, 4, 3, 2];
console.log(sum(arr));
console.log(multiply(arr));

// the output will be:
// The sum of the array elements is: 14
// The proudct of array elements is: 120

*/

/* Question 5 */

let reverse=(string) =>{
    return string.split("").reverse().join("");
}
console.log(reverse("Richard"));
// output will be:
//drahciR

 // another way

function reverse2(str) {
    let reversed = "";
    for (let i = str.length - 1; i >= 0; i--) {
        reversed += str[i]
    }
    return reversed;
}
console.log(reverse2("Richard"));
     // output will be:
    //drahciR


        /*Question 6 */


    function findLongestWord(array) {
        let longestword;
        if(array instanceof Array){
             longestword= array.reduce((long,current)=> current.length>long.length?current:long);
        return "the the lenght of the longest word is: "+longestword.length;
        }
        else
            return "invalid input. please input an array of strings"
    }

    var a= new Array("emma","emm","em");
    console.log(findLongestWord(a));
    //the the lenght of the longest word is: 4
   
    console.log(findLongestWord("emma emm em"));
    //invalid input. please input an array of strings

    

    /* Question 7 */



function filterLongWords(array, i) {
    if (array instanceof Array)
        return array.filter(x => x.length > i.length)
    else
        return "invalid input. please input an array of strings"
}

/*
let arrayofWords = ["emma", "richard", "Ndahiro", "John of cross"]
console.log(filterLongWords(arrayofWords, "emmy"));
//the output wil be:
//["richard", "Ndahiro"," John of cross]"
*/

/* Question 8 */

function multiply(arrayNum) {
    if (!(arrayNum instanceof Array))
        return "invalid input of array";
    return "The product of array elements is:" + arrayNum.reduce((x, y) => x * y, 1);
}

function sum(arrayNum) {
    if (!(arrayNum instanceof Array))
        return "invalid input of array";
    return "The product of array elements is:" + arrayNum.reduce((x, y) => x + y, 0);
}

/*

console.log(sum(1));
console.log(multiply(1));

//output will be:
//invalid input of array
//invalid input of array

var arr = [5, 4, 3, 2];
console.log(sum(arr));
console.log(multiply(arr));

// the output will be:
// The sum of the array elements is: 14
// The proudct of array elements is: 120


*/

/* Question  9 */

function findSecondBiggest(NumericArray) {
    if (!NumericArray.some(isNaN)) {
        let max = 0;
        let secondmax = NumericArray[0];
        for (let i = 0; i < NumericArray.length; i++) {
            if (NumericArray[i] > max) {
                secondmax = max;
                max = NumericArray[i];
            }
            else if (NumericArray[i] < max && NumericArray[i] >= secondmax)
                secondmax = NumericArray[i];

        }
        return secondmax;
    }
    else {
        return "invalid input of numeric array";
    }

}

/* 
console.log(findSecondBiggest([1, 2, 3, 4, 5]));
// output will be: 4

console.log(findSecondBiggest([19, 9, 11, 0, 12]));
// output will be: 12
console.log(findSecondBiggest(1));
    //will throw an error:
    //NumericArray.some is not a function

*/
let printFibo = (a,b,n)=>{
    console.log(a);
    if(n<=1) return;
    
    let sum=a+b;

    return printFibo(b,sum,n-1);
    
}

printFibo(0,1,10);
// output will be
// 0, 1, 1, 2, 3, 5, 8, 13, 21, 34
